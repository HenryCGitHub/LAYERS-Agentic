@tool
extends Node

signal epic_updated(payload: Dictionary)
signal sync_failed(message: String)
signal busy_changed(is_busy: bool)
signal update_available(local_ver: String, remote_ver: String)
signal update_check_finished(up_to_date: bool, local_ver: String, remote_ver: String)
signal update_ready_to_reload(new_ver: String, updated_gd_paths: PackedStringArray)
signal update_failed(message: String)

const DEFAULT_SYNC_BASE_URL := "https://us-central1-layers-b8a16.cloudfunctions.net/geminiProxy"
const CONFIG_DIR := "res://.layers"
const LINK_CFG_PATH := "res://.layers/link.cfg"
const CACHE_JSON_PATH := "res://.layers/epic_cache.json"
const PLUGIN_CFG_PATH := "res://addons/layers/plugin.cfg"
const UPDATE_TMP_ZIP_PATH := "res://.layers/plugin_update.zip"
const REMOTE_PLUGIN_CFG_URL := "https://raw.githubusercontent.com/HenryCGitHub/LAYERS-Agentic/main/godot_plugin/addons/layers/plugin.cfg"
const REMOTE_ZIP_PRIMARY_URL := "https://raw.githubusercontent.com/HenryCGitHub/LAYERS-Agentic/main/web/layers_godot_plugin.zip"
const REMOTE_ZIP_FALLBACK_URL := "https://henrycgithub.github.io/LAYERS-Agentic/layers_godot_plugin.zip"

var _http: HTTPRequest
var _update_http: HTTPRequest
var _link_token: String = ""
var _sync_base_url: String = DEFAULT_SYNC_BASE_URL
var _is_busy: bool = false
var _pending_queue: Array[Dictionary] = []
var _update_busy: bool = false
var _update_mode: String = ""
var _update_silent: bool = true
var _update_zip_attempt_idx: int = 0


func _ready() -> void:
	_http = HTTPRequest.new()
	_http.timeout = 45.0
	add_child(_http)
	_http.request_completed.connect(_on_request_completed)

	_update_http = HTTPRequest.new()
	_update_http.timeout = 30.0
	add_child(_update_http)
	_update_http.request_completed.connect(_on_update_http_completed)

	load_config()


func has_link_token() -> bool:
	return _link_token.begins_with("lyr_") and _link_token.length() >= 20


func get_link_token() -> String:
	return _link_token


func load_config() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(LINK_CFG_PATH) == OK:
		_link_token = str(cfg.get_value("layers", "link_token", "")).strip_edges()
		var saved_url := str(cfg.get_value("layers", "sync_base_url", DEFAULT_SYNC_BASE_URL)).strip_edges()
		if not saved_url.is_empty():
			_sync_base_url = saved_url.trim_suffix("/")
	else:
		_link_token = ""
		_sync_base_url = DEFAULT_SYNC_BASE_URL


func save_link_token(token: String, base_url: String = DEFAULT_SYNC_BASE_URL) -> void:
	_ensure_layers_dir()
	_link_token = token.strip_edges()
	var clean_url := base_url.strip_edges().trim_suffix("/")
	if not clean_url.is_empty():
		_sync_base_url = clean_url
	var cfg := ConfigFile.new()
	cfg.set_value("layers", "link_token", _link_token)
	cfg.set_value("layers", "sync_base_url", _sync_base_url)
	cfg.save(LINK_CFG_PATH)


func clear_link_token() -> void:
	_link_token = ""
	_pending_queue.clear()
	if FileAccess.file_exists(LINK_CFG_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(LINK_CFG_PATH))
	if FileAccess.file_exists(CACHE_JSON_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(CACHE_JSON_PATH))


func load_cached_epic() -> Dictionary:
	if not FileAccess.file_exists(CACHE_JSON_PATH):
		return {}
	var file := FileAccess.open(CACHE_JSON_PATH, FileAccess.READ)
	if file == null:
		return {}
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if typeof(parsed) == TYPE_DICTIONARY:
		return parsed as Dictionary
	return {}


func save_cached_epic(payload: Dictionary) -> void:
	if payload.is_empty():
		return
	_write_cache(payload)


func fetch_active_epic() -> void:
	if not has_link_token():
		return
	_dispatch_or_queue({
		"kind": "get_epic",
		"method": HTTPClient.METHOD_GET,
		"path": "/godotLink/epic",
		"body": "",
	})


func set_playtest_passed(feature_id: String, checkpoint_id: String, passed: bool) -> void:
	if not has_link_token():
		return
	_dispatch_or_queue({
		"kind": "update",
		"method": HTTPClient.METHOD_POST,
		"path": "/godotLink/update",
		"body": JSON.stringify({
			"featureId": feature_id,
			"checkpointId": checkpoint_id,
			"action": "set_playtest",
			"passed": passed,
		}),
	})


func toggle_guard(
	feature_id: String,
	checkpoint_id: String,
	guard_index: int,
	guard_text: String,
	signed_off: bool
) -> void:
	if not has_link_token():
		return
	_dispatch_or_queue({
		"kind": "update",
		"method": HTTPClient.METHOD_POST,
		"path": "/godotLink/update",
		"body": JSON.stringify({
			"featureId": feature_id,
			"checkpointId": checkpoint_id,
			"action": "toggle_guard",
			"guardIndex": guard_index,
			"guardText": guard_text,
			"signedOff": signed_off,
		}),
	})


func log_playtest_issue(feature_id: String, checkpoint_id: String, issue_text: String) -> void:
	if not has_link_token():
		return
	var clean_issue: String = issue_text.strip_edges()
	if clean_issue.is_empty():
		return
	_dispatch_or_queue({
		"kind": "update",
		"method": HTTPClient.METHOD_POST,
		"path": "/godotLink/update",
		"body": JSON.stringify({
			"featureId": feature_id,
			"checkpointId": checkpoint_id,
			"action": "log_issue",
			"issueText": clean_issue,
		}),
	})


func resolve_playtest_issue(feature_id: String, checkpoint_id: String, issue_id: String) -> void:
	if not has_link_token():
		return
	var clean_id: String = issue_id.strip_edges()
	if clean_id.is_empty():
		return
	_dispatch_or_queue({
		"kind": "update",
		"method": HTTPClient.METHOD_POST,
		"path": "/godotLink/update",
		"body": JSON.stringify({
			"featureId": feature_id,
			"checkpointId": checkpoint_id,
			"action": "resolve_issue",
			"issueId": clean_id,
		}),
	})


func _ensure_layers_dir() -> void:
	var abs_dir := ProjectSettings.globalize_path(CONFIG_DIR)
	if not DirAccess.dir_exists_absolute(abs_dir):
		DirAccess.make_dir_recursive_absolute(abs_dir)
	var gdignore_path := "%s/.gdignore" % CONFIG_DIR
	if not FileAccess.file_exists(gdignore_path):
		var f_gd := FileAccess.open(gdignore_path, FileAccess.WRITE)
		if f_gd != null:
			f_gd.store_string("")
	var gitignore_path := "%s/.gitignore" % CONFIG_DIR
	if not FileAccess.file_exists(gitignore_path):
		var f_git := FileAccess.open(gitignore_path, FileAccess.WRITE)
		if f_git != null:
			f_git.store_string("*\n")


func _dispatch_or_queue(req: Dictionary) -> void:
	if _http == null:
		return
	if _is_busy:
		var req_kind: String = str(req.get("kind", ""))
		if req_kind == "update":
			_pending_queue.append(req)
		elif req_kind == "get_epic" and _pending_queue.is_empty():
			_pending_queue.append(req)
		return
	_start_request(req)


func _start_request(req: Dictionary) -> void:
	_is_busy = true
	busy_changed.emit(true)

	var url := "%s%s" % [_sync_base_url, str(req.get("path", ""))]
	var headers := PackedStringArray([
		"Authorization: Bearer %s" % _link_token,
		"Content-Type: application/json",
	])
	var method := int(req.get("method", HTTPClient.METHOD_GET))
	var body := str(req.get("body", ""))

	var err := _http.request(url, headers, method, body)
	if err != OK:
		_is_busy = false
		busy_changed.emit(false)
		sync_failed.emit("HTTP request failed (%s)" % error_string(err))


func _on_request_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	_is_busy = false
	busy_changed.emit(false)

	var text := body.get_string_from_utf8()
	var parsed: Variant = JSON.parse_string(text)

	if result != HTTPRequest.RESULT_SUCCESS:
		sync_failed.emit("Offline or network error (%d)" % result)
	elif response_code < 200 or response_code >= 300:
		var err_msg := "Sync error (%d)" % response_code
		if typeof(parsed) == TYPE_DICTIONARY:
			var err_obj: Variant = (parsed as Dictionary).get("error", {})
			if typeof(err_obj) == TYPE_DICTIONARY and (err_obj as Dictionary).has("message"):
				err_msg = str((err_obj as Dictionary)["message"])
		sync_failed.emit(err_msg)
	elif typeof(parsed) == TYPE_DICTIONARY and (parsed as Dictionary).get("ok", false) == true:
		var payload_dict: Dictionary = parsed as Dictionary
		_write_cache(payload_dict)
		epic_updated.emit(payload_dict)
	else:
		sync_failed.emit("Unexpected sync response.")

	if not _pending_queue.is_empty():
		var next_req: Dictionary = _pending_queue.pop_front()
		_start_request(next_req)


func _write_cache(payload: Dictionary) -> void:
	_ensure_layers_dir()
	var file := FileAccess.open(CACHE_JSON_PATH, FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify(payload))


func get_local_plugin_version() -> String:
	var cfg := ConfigFile.new()
	if cfg.load(PLUGIN_CFG_PATH) == OK:
		var ver := str(cfg.get_value("plugin", "version", "0.0.0")).strip_edges()
		if not ver.is_empty():
			return ver
	return "0.0.0"


func _parse_semver_parts(raw_ver: String) -> PackedInt32Array:
	var clean := raw_ver.strip_edges().trim_prefix("v").trim_prefix("V")
	var core := clean.split("-", false, 1)[0].split("+", false, 1)[0]
	var segs := core.split(".", false)
	var out := PackedInt32Array()
	for s in segs:
		var t := s.strip_edges()
		out.append(t.to_int() if t.is_valid_int() else 0)
	return out


func _is_newer_version(local_ver: String, remote_ver: String) -> bool:
	var loc := _parse_semver_parts(local_ver)
	var rem := _parse_semver_parts(remote_ver)
	if rem.is_empty():
		return false
	var max_len := maxi(loc.size(), rem.size())
	for i in range(max_len):
		var l_val := loc[i] if i < loc.size() else 0
		var r_val := rem[i] if i < rem.size() else 0
		if r_val > l_val:
			return true
		if r_val < l_val:
			return false
	return false


func check_for_plugin_update(silent: bool = true) -> void:
	if _update_http == null or _update_busy:
		return
	_update_busy = true
	_update_mode = "check"
	_update_silent = silent
	var url := "%s?t=%d" % [REMOTE_PLUGIN_CFG_URL, int(Time.get_unix_time_from_system() * 1000.0)]
	var headers := PackedStringArray([
		"Cache-Control: no-cache",
		"Pragma: no-cache",
	])
	var err := _update_http.request(url, headers, HTTPClient.METHOD_GET)
	if err != OK:
		_update_busy = false
		_update_mode = ""
		if not _update_silent:
			update_failed.emit("Could not check GitHub for plugin updates (%s)." % error_string(err))


func _get_remote_zip_urls() -> PackedStringArray:
	return PackedStringArray([
		REMOTE_ZIP_PRIMARY_URL,
		REMOTE_ZIP_FALLBACK_URL,
	])


func download_and_apply_plugin_update() -> void:
	if _update_http == null or _update_busy:
		return
	_update_busy = true
	_update_mode = "download"
	_update_silent = false
	_update_zip_attempt_idx = 0
	_start_zip_download_attempt(0)


func _start_zip_download_attempt(idx: int) -> void:
	var zip_urls: PackedStringArray = _get_remote_zip_urls()
	if idx < 0 or idx >= zip_urls.size():
		_update_busy = false
		_update_mode = ""
		update_failed.emit("Failed to download plugin update archive.")
		return
	var base_url: String = zip_urls[idx]
	var url := "%s?t=%d" % [base_url, int(Time.get_unix_time_from_system() * 1000.0)]
	var headers := PackedStringArray([
		"Cache-Control: no-cache",
		"Pragma: no-cache",
	])
	var err := _update_http.request(url, headers, HTTPClient.METHOD_GET)
	if err != OK:
		if idx + 1 < zip_urls.size():
			_update_zip_attempt_idx = idx + 1
			_start_zip_download_attempt(_update_zip_attempt_idx)
		else:
			_update_busy = false
			_update_mode = ""
			update_failed.emit("Failed to download plugin update archive (%s)." % error_string(err))


func _on_update_http_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	var mode := _update_mode
	if mode == "check":
		_update_busy = false
		_update_mode = ""
		if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
			if not _update_silent:
				update_failed.emit("Could not check GitHub for plugin updates.")
			return
		var cfg := ConfigFile.new()
		var text := body.get_string_from_utf8()
		if cfg.parse(text) != OK:
			if not _update_silent:
				update_failed.emit("Could not check GitHub for plugin updates.")
			return
		var remote_ver := str(cfg.get_value("plugin", "version", "")).strip_edges()
		var local_ver := get_local_plugin_version()
		if remote_ver.is_empty():
			if not _update_silent:
				update_failed.emit("Could not check GitHub for plugin updates.")
			return
		if _is_newer_version(local_ver, remote_ver):
			update_available.emit(local_ver, remote_ver)
			update_check_finished.emit(false, local_ver, remote_ver)
		else:
			update_check_finished.emit(true, local_ver, remote_ver)
		return

	if mode == "download":
		var zip_urls: PackedStringArray = _get_remote_zip_urls()
		if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300 or body.size() < 200:
			if _update_zip_attempt_idx + 1 < zip_urls.size():
				_update_zip_attempt_idx += 1
				_start_zip_download_attempt(_update_zip_attempt_idx)
			else:
				_update_busy = false
				_update_mode = ""
				update_failed.emit("Failed to download plugin update archive.")
			return
		_apply_downloaded_zip_bytes(body)


func _apply_downloaded_zip_bytes(zip_bytes: PackedByteArray) -> void:
	_ensure_layers_dir()
	var tmp_file := FileAccess.open(UPDATE_TMP_ZIP_PATH, FileAccess.WRITE)
	if tmp_file == null:
		_update_busy = false
		_update_mode = ""
		update_failed.emit("Could not write temporary plugin update archive.")
		return
	tmp_file.store_buffer(zip_bytes)
	tmp_file.close()

	var tmp_abs := ProjectSettings.globalize_path(UPDATE_TMP_ZIP_PATH)
	var reader := ZIPReader.new()
	if reader.open(tmp_abs) != OK:
		DirAccess.remove_absolute(tmp_abs)
		_update_busy = false
		_update_mode = ""
		update_failed.emit("Downloaded plugin archive is invalid.")
		return

	var files: PackedStringArray = reader.get_files()
	var required_entries := PackedStringArray([
		"addons/layers/plugin.cfg",
		"addons/layers/layers_plugin.gd",
		"addons/layers/layers_dock.gd",
		"addons/layers/layers_sync_client.gd",
		"addons/layers/layers_step_executor.gd",
	])
	for req in required_entries:
		if not files.has(req) or reader.read_file(req).size() <= 0:
			reader.close()
			DirAccess.remove_absolute(tmp_abs)
			_update_busy = false
			_update_mode = ""
			update_failed.emit("Plugin archive missing required file: %s" % req)
			return

	var updated_gd_paths := PackedStringArray()
	for entry in files:
		if not entry.begins_with("addons/layers/"):
			continue
		if entry.ends_with("/"):
			continue
		if ".." in entry:
			continue
		var data := reader.read_file(entry)
		var dest_res := "res://" + entry
		var dest_dir_abs := ProjectSettings.globalize_path(dest_res.get_base_dir())
		if not DirAccess.dir_exists_absolute(dest_dir_abs):
			DirAccess.make_dir_recursive_absolute(dest_dir_abs)
		var out_f := FileAccess.open(dest_res, FileAccess.WRITE)
		if out_f == null:
			reader.close()
			DirAccess.remove_absolute(tmp_abs)
			_update_busy = false
			_update_mode = ""
			update_failed.emit("Failed to write %s during update." % dest_res)
			return
		out_f.store_buffer(data)
		out_f.close()
		if dest_res.ends_with(".gd"):
			updated_gd_paths.append(dest_res)

	reader.close()
	DirAccess.remove_absolute(tmp_abs)

	_update_busy = false
	_update_mode = ""
	var new_ver := get_local_plugin_version()
	update_ready_to_reload.emit(new_ver, updated_gd_paths)
