@tool
extends VBoxContainer

const SYNC_CLIENT_SCRIPT_PATH := "res://addons/layers/layers_sync_client.gd"
const STEP_EXECUTOR_SCRIPT_PATH := "res://addons/layers/layers_step_executor.gd"
const AGENT_CONTROLLER_SCRIPT_PATH := "res://addons/layers/layers_agent_controller.gd"
const DEFAULT_WEB_STUDIO_URL := "https://henrycgithub.github.io/LAYERS-Agentic/"
const MAX_AGENT_TURNS := 6
const MAX_AUTO_HEAL_ATTEMPTS := 3


var editor_interface: Variant = null
var undo_redo: Variant = null

var _sync_client: Node = null
var _executor: RefCounted = null
var _agent_ctrl: RefCounted = null
var _logger: Logger = null
var _logger_registered: bool = false

var _payload: Dictionary = {}
var _last_bundle_snapshot: Dictionary = {}
var _auto_heal_count: int = 0
var _agent_session: Dictionary = {}
var _status_message: String = ""
var _status_is_error: bool = false
var _available_update_ver: String = ""
var _pending_build_preferred_scene: String = ""
var _last_built_scene_path: String = ""
var _errors_cleared_unix: float = 0.0
var _ignored_error_signatures: Dictionary = {}
var _manual_update_check: bool = false
var _show_token_fallback: bool = false

# UI Nodes
var _title_label: Label
var _dim_badge: Label
var _sync_btn: Button
var _studio_btn: Button
var _menu_btn: MenuButton

var _update_banner: PanelContainer
var _update_label: Label
var _update_apply_btn: Button

var _status_label: Label

var _unlinked_panel: PanelContainer
var _google_signin_btn: Button
var _cancel_signin_btn: Button
var _toggle_token_btn: Button
var _token_row: HBoxContainer
var _token_input: LineEdit
var _token_save_btn: Button

var _linked_scroll: ScrollContainer
var _linked_box: VBoxContainer
var _project_meta_label: Label
var _epic_selector: OptionButton
var _feature_selector: OptionButton
var _locked_baseline_label: Label

var _primary_cta_btn: Button
var _cancel_agent_btn: Button
var _play_btn: Button
var _undo_btn: Button

var _goal_hdr: Label
var _goal_label: Label
var _deltas_box: VBoxContainer
var _tuning_hdr: Label
var _tuning_box: VBoxContainer
var _checks_hdr: Label
var _checks_box: VBoxContainer
var _pass_reopen_btn: Button

var _errors_card: PanelContainer
var _errors_list_box: VBoxContainer
var _clear_errors_btn: Button
var _auto_fix_errors_btn: Button

var _fixes_box: VBoxContainer
var _fix_input: LineEdit
var _flag_fix_btn: Button


func _enter_tree() -> void:
	name = "LAYERS"
	if Engine.is_editor_hint() and _logger == null:
		var ctrl: RefCounted = _ensure_agent_ctrl()
		_logger = ctrl.call("create_editor_logger") as Logger if ctrl != null else null
		if _logger != null and OS.has_method("add_logger"):
			OS.call("add_logger", _logger)
			_logger_registered = true


func _exit_tree() -> void:
	if _logger != null and _logger_registered:
		if OS.has_method("remove_logger"):
			OS.call("remove_logger", _logger)
		_logger_registered = false
		_logger = null


func _ready() -> void:
	_init_helpers()
	_build_ui()
	_wire_signals()

	if _sync_client != null:
		var cached: Dictionary = _sync_client.call("load_cached_epic") as Dictionary
		if not cached.is_empty():
			_payload = cached
		_refresh_ui()
		if bool(_sync_client.call("has_link_token")):
			_sync_with_cloud()
		if Engine.is_editor_hint():
			_sync_client.call("check_for_plugin_update", true)


func _load_fresh_helper_script(res_path: String) -> Script:
	if not FileAccess.file_exists(res_path):
		return null
	var disk_code: String = FileAccess.get_file_as_string(res_path)
	if disk_code.strip_edges().is_empty():
		return null
	if ResourceLoader.has_cached(res_path):
		var cached: Variant = ResourceLoader.load(res_path)
		if cached is GDScript:
			var cached_gds: GDScript = cached as GDScript
			cached_gds.source_code = disk_code
			if cached_gds.reload(true) == OK:
				return cached_gds
	var fresh: Variant = ResourceLoader.load(res_path, "Script", ResourceLoader.CACHE_MODE_IGNORE)
	if fresh is GDScript:
		return fresh as Script
	var fallback: Variant = load(res_path)
	return fallback as Script if fallback is Script else null


func _ensure_agent_ctrl() -> RefCounted:
	if _agent_ctrl == null:
		var ctrl_scr: Script = _load_fresh_helper_script(AGENT_CONTROLLER_SCRIPT_PATH)
		if ctrl_scr != null:
			_agent_ctrl = ctrl_scr.new(self)
	return _agent_ctrl


func _init_helpers() -> void:
	var step_scr: Script = _load_fresh_helper_script(STEP_EXECUTOR_SCRIPT_PATH)
	if step_scr != null:
		_executor = step_scr.new()

	var sync_scr: Script = _load_fresh_helper_script(SYNC_CLIENT_SCRIPT_PATH)
	if sync_scr != null:
		_sync_client = sync_scr.new() as Node
		if _sync_client != null:
			add_child(_sync_client)
	_ensure_agent_ctrl()


func _build_ui() -> void:
	custom_minimum_size = Vector2(270, 0)
	add_theme_constant_override("separation", 8)

	# Top Header Bar
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 6)
	add_child(header)

	_title_label = Label.new()
	_title_label.text = "LAYERS"
	_title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_title_label.add_theme_font_size_override("font_size", 14)
	header.add_child(_title_label)

	_dim_badge = Label.new()
	_dim_badge.text = "3D"
	_dim_badge.add_theme_font_size_override("font_size", 11)
	header.add_child(_dim_badge)

	_sync_btn = Button.new()
	_sync_btn.text = "↻"
	_sync_btn.tooltip_text = "Sync Active Epic Spec & Project Snapshot"
	header.add_child(_sync_btn)

	_studio_btn = Button.new()
	_studio_btn.text = "Studio"
	_studio_btn.tooltip_text = "Open Web Studio"
	header.add_child(_studio_btn)

	_menu_btn = MenuButton.new()
	_menu_btn.text = "⚙"
	_menu_btn.tooltip_text = "Plugin Settings & Account"
	var popup := _menu_btn.get_popup()
	popup.add_item("Sign in with Google", 1)
	popup.add_item("Check Plugin Updates", 2)
	popup.add_item("Clear Captured Errors", 3)
	popup.add_separator()
	popup.add_item("Unlink Project", 4)
	header.add_child(_menu_btn)

	# Self-update banner
	_update_banner = PanelContainer.new()
	_update_banner.visible = false
	add_child(_update_banner)
	var ub_row := HBoxContainer.new()
	ub_row.add_theme_constant_override("separation", 6)
	_update_banner.add_child(ub_row)
	_update_label = Label.new()
	_update_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_update_label.add_theme_font_size_override("font_size", 11)
	ub_row.add_child(_update_label)
	_update_apply_btn = Button.new()
	_update_apply_btn.text = "Update"
	ub_row.add_child(_update_apply_btn)

	# Status line
	_status_label = Label.new()
	_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status_label.add_theme_font_size_override("font_size", 11)
	_status_label.visible = false
	add_child(_status_label)

	# Unlinked Card
	_unlinked_panel = PanelContainer.new()
	add_child(_unlinked_panel)
	var ul_box := VBoxContainer.new()
	ul_box.add_theme_constant_override("separation", 8)
	_unlinked_panel.add_child(ul_box)

	var ul_title := Label.new()
	ul_title.text = "Connect Godot 4 to LAYERS Studio"
	ul_title.add_theme_font_size_override("font_size", 13)
	ul_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ul_box.add_child(ul_title)

	var ul_desc := Label.new()
	ul_desc.text = "Sign in once with Google to stream your Epic spec and enable 1-click Build & Playtest repair inside Godot."
	ul_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ul_desc.add_theme_font_size_override("font_size", 11)
	ul_box.add_child(ul_desc)

	_google_signin_btn = Button.new()
	_google_signin_btn.text = "⚡ Sign in with Google"
	ul_box.add_child(_google_signin_btn)

	_cancel_signin_btn = Button.new()
	_cancel_signin_btn.text = "Cancel Waiting for Browser"
	_cancel_signin_btn.visible = false
	ul_box.add_child(_cancel_signin_btn)

	_toggle_token_btn = Button.new()
	_toggle_token_btn.text = "Use fallback lyr_ token instead ▾"
	_toggle_token_btn.flat = true
	ul_box.add_child(_toggle_token_btn)

	_token_row = HBoxContainer.new()
	_token_row.visible = false
	_token_row.add_theme_constant_override("separation", 6)
	ul_box.add_child(_token_row)

	_token_input = LineEdit.new()
	_token_input.placeholder_text = "Paste lyr_... token"
	_token_input.secret = true
	_token_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_token_row.add_child(_token_input)

	_token_save_btn = Button.new()
	_token_save_btn.text = "Link"
	_token_row.add_child(_token_save_btn)

	# Linked Workspace Scroll
	_linked_scroll = ScrollContainer.new()
	_linked_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_linked_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(_linked_scroll)

	_linked_box = VBoxContainer.new()
	_linked_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_linked_box.add_theme_constant_override("separation", 10)
	_linked_scroll.add_child(_linked_box)

	_project_meta_label = Label.new()
	_project_meta_label.text = "Project · v0.1"
	_project_meta_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_project_meta_label.add_theme_font_size_override("font_size", 12)
	_linked_box.add_child(_project_meta_label)

	_epic_selector = OptionButton.new()
	_epic_selector.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_linked_box.add_child(_epic_selector)

	_feature_selector = OptionButton.new()
	_feature_selector.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_feature_selector.visible = false
	_linked_box.add_child(_feature_selector)

	_locked_baseline_label = Label.new()
	_locked_baseline_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_locked_baseline_label.add_theme_font_size_override("font_size", 11)
	_locked_baseline_label.add_theme_color_override("font_color", Color(0.96, 0.75, 0.35))
	_locked_baseline_label.visible = false
	_linked_box.add_child(_locked_baseline_label)

	# Action Row: Build/Fix/Pass + Play + Undo
	var action_row := HBoxContainer.new()
	action_row.add_theme_constant_override("separation", 6)
	_linked_box.add_child(action_row)

	_primary_cta_btn = Button.new()
	_primary_cta_btn.text = "⚡ Build E01"
	_primary_cta_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	action_row.add_child(_primary_cta_btn)

	_cancel_agent_btn = Button.new()
	_cancel_agent_btn.text = "✕ Cancel"
	_cancel_agent_btn.tooltip_text = "Cancel running Cloud Gemini loop"
	_cancel_agent_btn.visible = false
	_cancel_agent_btn.disabled = true
	action_row.add_child(_cancel_agent_btn)

	_play_btn = Button.new()
	_play_btn.text = "▶ Play"
	_play_btn.tooltip_text = "Run Test Scene (or Main Scene)"
	action_row.add_child(_play_btn)

	_undo_btn = Button.new()
	_undo_btn.text = "↶ Undo"
	_undo_btn.tooltip_text = "Restore files/scenes/InputMap to before last AI build"
	_undo_btn.disabled = true
	action_row.add_child(_undo_btn)

	# Intent / Deltas Card
	var goal_card := PanelContainer.new()
	_linked_box.add_child(goal_card)
	var goal_vbox := VBoxContainer.new()
	goal_vbox.add_theme_constant_override("separation", 6)
	goal_card.add_child(goal_vbox)

	_goal_hdr = Label.new()
	_goal_hdr.text = "§01 FEATURE SCOPE"
	_goal_hdr.add_theme_font_size_override("font_size", 10)
	goal_vbox.add_child(_goal_hdr)

	_goal_label = Label.new()
	_goal_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_goal_label.add_theme_font_size_override("font_size", 12)
	goal_vbox.add_child(_goal_label)

	_deltas_box = VBoxContainer.new()
	_deltas_box.add_theme_constant_override("separation", 3)
	goal_vbox.add_child(_deltas_box)

	# Captured Errors Card
	_errors_card = PanelContainer.new()
	_errors_card.visible = false
	_linked_box.add_child(_errors_card)
	var err_vbox := VBoxContainer.new()
	err_vbox.add_theme_constant_override("separation", 6)
	_errors_card.add_child(err_vbox)

	var err_hdr_row := HBoxContainer.new()
	err_hdr_row.add_theme_constant_override("separation", 6)
	err_vbox.add_child(err_hdr_row)

	var err_hdr := Label.new()
	err_hdr.text = "DETECTED GODOT ERRORS"
	err_hdr.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	err_hdr.add_theme_font_size_override("font_size", 10)
	err_hdr_row.add_child(err_hdr)

	_clear_errors_btn = Button.new()
	_clear_errors_btn.text = "Clear"
	_clear_errors_btn.tooltip_text = "Acknowledge & clear detected errors"
	err_hdr_row.add_child(_clear_errors_btn)

	_errors_list_box = VBoxContainer.new()
	_errors_list_box.add_theme_constant_override("separation", 3)
	err_vbox.add_child(_errors_list_box)

	_auto_fix_errors_btn = Button.new()
	_auto_fix_errors_btn.text = "🔧 Fix Detected Errors with Gemini"
	err_vbox.add_child(_auto_fix_errors_btn)

	# §04 Spatial & Exposed Tuning Card
	var tuning_card := PanelContainer.new()
	_linked_box.add_child(tuning_card)
	var tuning_vbox := VBoxContainer.new()
	tuning_vbox.add_theme_constant_override("separation", 6)
	tuning_card.add_child(tuning_vbox)

	_tuning_hdr = Label.new()
	_tuning_hdr.text = "§03 @export TUNING"
	_tuning_hdr.add_theme_font_size_override("font_size", 10)
	tuning_vbox.add_child(_tuning_hdr)

	_tuning_box = VBoxContainer.new()
	_tuning_box.add_theme_constant_override("separation", 4)
	tuning_vbox.add_child(_tuning_box)

	# Playtest Acceptance Gate Card
	var checks_card := PanelContainer.new()
	_linked_box.add_child(checks_card)
	var checks_vbox := VBoxContainer.new()
	checks_vbox.add_theme_constant_override("separation", 6)
	checks_card.add_child(checks_vbox)

	_checks_hdr = Label.new()
	_checks_hdr.text = "§05 PLAYTEST GATE"
	_checks_hdr.add_theme_font_size_override("font_size", 10)
	checks_vbox.add_child(_checks_hdr)

	_checks_box = VBoxContainer.new()
	_checks_box.add_theme_constant_override("separation", 4)
	checks_vbox.add_child(_checks_box)

	_pass_reopen_btn = Button.new()
	_pass_reopen_btn.text = "Pass Epic ✓"
	checks_vbox.add_child(_pass_reopen_btn)

	# [FIX] Revisions Card
	var fixes_card := PanelContainer.new()
	_linked_box.add_child(fixes_card)
	var fixes_vbox := VBoxContainer.new()
	fixes_vbox.add_theme_constant_override("separation", 6)
	fixes_card.add_child(fixes_vbox)

	var fixes_hdr := Label.new()
	fixes_hdr.text = "[FIX] PLAYTEST REVISIONS"
	fixes_hdr.add_theme_font_size_override("font_size", 10)
	fixes_vbox.add_child(fixes_hdr)

	_fixes_box = VBoxContainer.new()
	_fixes_box.add_theme_constant_override("separation", 4)
	fixes_vbox.add_child(_fixes_box)

	var fix_row := HBoxContainer.new()
	fix_row.add_theme_constant_override("separation", 6)
	fixes_vbox.add_child(fix_row)

	_fix_input = LineEdit.new()
	_fix_input.placeholder_text = "Flag broken feel or bug..."
	_fix_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fix_row.add_child(_fix_input)

	_flag_fix_btn = Button.new()
	_flag_fix_btn.text = "+ [FIX]"
	fix_row.add_child(_flag_fix_btn)


func _wire_signals() -> void:
	_sync_btn.pressed.connect(_sync_with_cloud)
	_studio_btn.pressed.connect(_open_web_studio)
	_menu_btn.get_popup().id_pressed.connect(_on_menu_id_pressed)
	_update_apply_btn.pressed.connect(_on_apply_update_pressed)

	_google_signin_btn.pressed.connect(_on_google_signin_pressed)
	_cancel_signin_btn.pressed.connect(_on_cancel_signin_pressed)
	_toggle_token_btn.pressed.connect(func() -> void:
		_show_token_fallback = not _show_token_fallback
		_token_row.visible = _show_token_fallback
	)
	_token_save_btn.pressed.connect(_on_save_token_pressed)
	_token_input.text_submitted.connect(func(_t: String) -> void: _on_save_token_pressed())

	_epic_selector.item_selected.connect(_on_epic_selected)
	_feature_selector.item_selected.connect(_on_feature_selected)
	_primary_cta_btn.pressed.connect(_on_primary_cta_pressed)
	_cancel_agent_btn.pressed.connect(_on_cancel_agent_pressed)
	_play_btn.pressed.connect(_on_play_pressed)
	_undo_btn.pressed.connect(_on_undo_pressed)
	_pass_reopen_btn.pressed.connect(_on_pass_reopen_pressed)
	_clear_errors_btn.pressed.connect(clear_captured_errors)
	_auto_fix_errors_btn.pressed.connect(func() -> void:
		_auto_heal_count = 0
		var fix_action: String = "fix_feature" if not _get_active_feature().is_empty() else "fix_epic"
		_trigger_epic_agent(fix_action)
	)
	_flag_fix_btn.pressed.connect(_on_flag_fix_pressed)
	_fix_input.text_submitted.connect(func(_t: String) -> void: _on_flag_fix_pressed())

	if _sync_client != null:
		_sync_client.connect("epic_updated", _on_epic_updated)
		_sync_client.connect("sync_failed", _on_sync_failed)
		_sync_client.connect("busy_changed", _on_busy_changed)
		_sync_client.connect("agent_busy_changed", _on_agent_busy_changed)
		_sync_client.connect("agent_bundle_received", _on_agent_bundle_received)
		_sync_client.connect("agent_step_received", _on_agent_step_received)
		_sync_client.connect("auth_completed", _on_auth_completed)
		_sync_client.connect("auth_status_changed", _on_auth_status_changed)
		_sync_client.connect("update_available", _on_update_available)
		_sync_client.connect("update_check_finished", _on_update_check_finished)
		_sync_client.connect("update_ready_to_reload", _on_update_ready_to_reload)
		_sync_client.connect("update_failed", _on_update_failed)


func on_editor_scene_changed(_scene_root: Node) -> void:
	_refresh_errors_card()


func on_editor_scene_saved(_filepath: String) -> void:
	_refresh_errors_card()


func on_editor_resource_saved(_resource: Resource) -> void:
	_refresh_errors_card()


func notify_editor_state_changed() -> void:
	_refresh_errors_card()


func _as_editor_interface() -> EditorInterface:
	return editor_interface as EditorInterface if editor_interface is EditorInterface else null


func _as_undo_redo() -> EditorUndoRedoManager:
	return undo_redo as EditorUndoRedoManager if undo_redo is EditorUndoRedoManager else null


func _resolve_play_scene_path() -> String:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	return ctrl.call("_resolve_play_scene_path") as String if ctrl != null else ""


func refresh_from_focus() -> void:
	if _sync_client != null and bool(_sync_client.call("has_link_token")) and not bool(_sync_client.call("is_busy")) and not bool(_sync_client.call("is_waiting_for_auth")):
		_sync_with_cloud()


func _collect_recent_errors() -> Array[String]:
	var out: Array[String] = []
	var ctrl: RefCounted = _ensure_agent_ctrl()
	if ctrl != null:
		var raw_v: Variant = ctrl.call("_collect_recent_errors")
		if typeof(raw_v) == TYPE_ARRAY:
			for item in (raw_v as Array):
				out.append(str(item))
	return out


func clear_captured_errors() -> void:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	if ctrl != null:
		ctrl.call("clear_captured_errors")


func inject_test_error(msg: String) -> void:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	if ctrl != null:
		ctrl.call("inject_test_error", msg)


func _collect_live_context() -> Dictionary:
	var errs: Array[String] = _collect_recent_errors()
	if _executor != null:
		var ctx_v: Variant = _executor.call("collect_godot_project_context", editor_interface, errs)
		if typeof(ctx_v) == TYPE_DICTIONARY:
			return ctx_v as Dictionary
	return {"recent_errors": errs}


func _sync_with_cloud(preferred_epic_id: String = "", preferred_feature_id: String = "") -> void:
	if _sync_client == null or not bool(_sync_client.call("has_link_token")):
		_refresh_ui()
		return
	var live_ctx: Dictionary = _collect_live_context()
	_sync_client.call("fetch_active_epic", live_ctx, preferred_epic_id, preferred_feature_id)


func _open_web_studio() -> void:
	var url: String = str(_payload.get("webStudioUrl", DEFAULT_WEB_STUDIO_URL)).strip_edges()
	if url.is_empty():
		url = DEFAULT_WEB_STUDIO_URL
	OS.shell_open(url)


func _on_menu_id_pressed(id: int) -> void:
	match id:
		1:
			_on_google_signin_pressed()
		2:
			if _sync_client != null:
				_manual_update_check = true
				_set_status("Checking GitHub for LAYERS plugin updates...", false)
				_sync_client.call("check_for_plugin_update", false)
		3:
			clear_captured_errors()
		4:
			if _sync_client != null:
				_sync_client.call("clear_link_token")
			_payload = {}
			_last_bundle_snapshot = {}
			_last_built_scene_path = ""
			_ignored_error_signatures.clear()
			_errors_cleared_unix = 0.0
			_set_status("Unlinked project.", false)
			_refresh_ui()


func _on_google_signin_pressed() -> void:
	if _sync_client == null:
		return
	var ctx: Dictionary = _collect_live_context()
	var proj_name: String = str(ctx.get("project_name", "GodotProject"))
	_sync_client.call("start_google_sign_in", proj_name, DEFAULT_WEB_STUDIO_URL, true)
	_refresh_ui()


func _on_cancel_signin_pressed() -> void:
	if _sync_client != null:
		_sync_client.call("cancel_google_sign_in")
	_refresh_ui()


func _on_save_token_pressed() -> void:
	var tok: String = _token_input.text.strip_edges()
	if not (tok.begins_with("lyr_") and tok.length() >= 20):
		_set_status("Enter a valid lyr_... token copied from LAYERS Web Studio.", true)
		return
	_token_input.text = ""
	if _sync_client != null:
		_sync_client.call("save_link_token", tok)
	_set_status("Token saved! Syncing active Epic...", false)
	_sync_with_cloud()


func _on_auth_completed(project_title: String) -> void:
	_set_status("Connected to %s! Pulling active Epic..." % (project_title if not project_title.is_empty() else "LAYERS"), false)
	_sync_with_cloud()


func _on_auth_status_changed(waiting: bool, message: String) -> void:
	_cancel_signin_btn.visible = waiting
	if _google_signin_btn != null:
		_google_signin_btn.text = "Waiting for Browser Sign-In..." if waiting else "⚡ Sign in with Google"
		_google_signin_btn.disabled = waiting
	if not message.is_empty():
		_set_status(message, false)


func _on_epic_updated(new_payload: Dictionary) -> void:
	_payload = new_payload
	_refresh_ui()


func _on_sync_failed(message: String) -> void:
	_agent_session = {}
	_auto_heal_count = 0
	_on_agent_busy_changed(false)
	_set_status(message, true)
	_refresh_ui()


func _on_busy_changed(busy: bool) -> void:
	if _sync_btn != null:
		_sync_btn.disabled = busy


func _on_agent_busy_changed(agent_busy: bool) -> void:
	var running: bool = agent_busy or bool(_agent_session.get("active", false))
	var locked: bool = _is_active_feature_locked()
	if _cancel_agent_btn != null:
		_cancel_agent_btn.visible = running
		_cancel_agent_btn.disabled = not running
	if _primary_cta_btn != null:
		_primary_cta_btn.disabled = running or locked
	if _auto_fix_errors_btn != null:
		_auto_fix_errors_btn.disabled = running or locked
	if _pass_reopen_btn != null:
		_pass_reopen_btn.disabled = running or locked
	if _epic_selector != null:
		_epic_selector.disabled = running
	if _feature_selector != null:
		_feature_selector.disabled = running
	if _flag_fix_btn != null:
		_flag_fix_btn.disabled = running or locked
	if _undo_btn != null:
		_undo_btn.disabled = running or _last_bundle_snapshot.is_empty()


func _on_epic_selected(idx: int) -> void:
	if idx < 0 or _epic_selector == null:
		return
	var meta_v: Variant = _epic_selector.get_item_metadata(idx)
	var eid: String = str(meta_v).strip_edges()
	if not eid.is_empty():
		_sync_with_cloud(eid)


func _on_feature_selected(idx: int) -> void:
	if idx < 0 or _feature_selector == null:
		return
	var meta_v: Variant = _feature_selector.get_item_metadata(idx)
	var fid: String = str(meta_v).strip_edges()
	var epic: Dictionary = _get_active_epic()
	var eid: String = str(epic.get("id", "")).strip_edges()
	if not eid.is_empty() and not fid.is_empty():
		_sync_with_cloud(eid, fid)


func _get_active_epic() -> Dictionary:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	return ctrl.call("_get_active_epic") as Dictionary if ctrl != null else {}


func _get_active_feature() -> Dictionary:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	return ctrl.call("_get_active_feature") as Dictionary if ctrl != null else {}


func _is_active_feature_locked() -> bool:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	return ctrl.call("_is_active_feature_locked") as bool if ctrl != null else false


func _get_active_target() -> Dictionary:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	return ctrl.call("_get_active_target") as Dictionary if ctrl != null else {}


func _get_active_target_code() -> String:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	return ctrl.call("_get_active_target_code") as String if ctrl != null else ""


func _get_active_target_checks() -> Array:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	return ctrl.call("_get_active_target_checks") as Array if ctrl != null else []


func _get_active_target_is_passed() -> bool:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	return ctrl.call("_get_active_target_is_passed") as bool if ctrl != null else false


func _sync_active_epic_summary_counts() -> void:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	if ctrl != null:
		ctrl.call("_sync_active_epic_summary_counts")


func compute_primary_cta_state() -> Dictionary:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	return ctrl.call("compute_primary_cta_state") as Dictionary if ctrl != null else {}


func _on_primary_cta_pressed() -> void:
	var epic: Dictionary = _get_active_epic()
	if epic.is_empty():
		_sync_with_cloud()
		return
	var feat: Dictionary = _get_active_feature()
	if _is_active_feature_locked():
		_set_status("Baseline %s is locked in this release." % _get_active_target_code(), false)
		return
	var cta: Dictionary = compute_primary_cta_state()
	var mode: String = str(cta.get("mode", "build"))
	if mode == "pass":
		if _sync_client != null:
			var mut := {
				"action": "pass_feature" if not feat.is_empty() else "pass_epic",
				"epicId": str(epic.get("id", "")),
			}
			if not feat.is_empty():
				mut["featureId"] = str(feat.get("id", ""))
			_sync_client.call("push_epic_mutation", mut, _collect_live_context())
		return
	_auto_heal_count = 0
	if mode == "fix":
		_trigger_epic_agent("fix_feature" if not feat.is_empty() else "fix_epic")
	else:
		_trigger_epic_agent("build_feature" if not feat.is_empty() else "build_epic")


func _trigger_epic_agent(action: String, extra_error_text: String = "") -> void:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	if ctrl != null:
		ctrl.call("_trigger_epic_agent", action, extra_error_text)


func _on_agent_step_received(agent_step: Dictionary, payload_resp: Dictionary) -> void:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	if ctrl != null:
		ctrl.call("_on_agent_step_received", agent_step, payload_resp)


func _on_cancel_agent_pressed() -> void:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	if ctrl != null:
		ctrl.call("_on_cancel_agent_pressed")


func _on_agent_bundle_received(agent_bundle: Dictionary, payload_resp: Dictionary) -> void:
	var ctrl: RefCounted = _ensure_agent_ctrl()
	if ctrl != null:
		ctrl.call("_on_agent_bundle_received", agent_bundle, payload_resp)


func _on_play_pressed() -> void:
	if editor_interface == null:
		return
	var target_scene: String = _resolve_play_scene_path()
	if target_scene.is_empty():
		var epic: Dictionary = _get_active_epic()
		var ecode: String = str(epic.get("code", "E01"))
		_set_status("No scene built yet — click ⚡ Build %s first." % ecode, true)
		return
	if editor_interface.has_method("save_scene"):
		editor_interface.call("save_scene")
	if editor_interface.has_method("play_custom_scene"):
		editor_interface.call("play_custom_scene", target_scene)
	elif editor_interface.has_method("play_main_scene"):
		editor_interface.call("play_main_scene")


func _on_undo_pressed() -> void:
	if _executor == null or _last_bundle_snapshot.is_empty():
		return
	var ed_int: EditorInterface = _as_editor_interface()
	var res_v: Variant = _executor.call("restore_bundle_snapshot", ed_int, _last_bundle_snapshot)
	var res: Dictionary = res_v as Dictionary if typeof(res_v) == TYPE_DICTIONARY else {}
	if bool(res.get("ok", false)):
		_last_bundle_snapshot = {}
		_undo_btn.disabled = true
		if ed_int != null and ed_int.get_resource_filesystem() != null:
			ed_int.get_resource_filesystem().scan()
		_set_status("Restored pre-build project snapshot.", false)
	else:
		_set_status("Nothing to undo.", true)


func toggle_epic_check_by_id(check_id: String, pressed: bool) -> void:
	var epic: Dictionary = _get_active_epic()
	if epic.is_empty():
		return
	if _is_active_feature_locked():
		_set_status("Baseline %s is read-only in this release." % _get_active_target_code(), false)
		return
	var feat: Dictionary = _get_active_feature()
	if not feat.is_empty():
		for arr_key in ["effectiveChecks", "checks", "releaseDeltaChecks"]:
			var arr_v: Variant = feat.get(arr_key, [])
			if typeof(arr_v) == TYPE_ARRAY:
				for cv in (arr_v as Array):
					if typeof(cv) == TYPE_DICTIONARY and str((cv as Dictionary).get("id", "")) == check_id:
						(cv as Dictionary)["passed"] = pressed
	else:
		var checks_v: Variant = epic.get("checks", [])
		if typeof(checks_v) == TYPE_ARRAY:
			for cv in (checks_v as Array):
				if typeof(cv) == TYPE_DICTIONARY and str((cv as Dictionary).get("id", "")) == check_id:
					(cv as Dictionary)["passed"] = pressed
					break
	_sync_active_epic_summary_counts()
	_refresh_ui()
	if _sync_client != null and bool(_sync_client.call("has_link_token")):
		var mut := {
			"action": "toggle_check",
			"epicId": str(epic.get("id", "")),
			"checkId": check_id,
			"passed": pressed,
		}
		if not feat.is_empty():
			mut["featureId"] = str(feat.get("id", ""))
		_sync_client.call("push_epic_mutation", mut, _collect_live_context())


func log_epic_fix_text(raw_text: String) -> String:
	var txt: String = raw_text.strip_edges()
	var epic: Dictionary = _get_active_epic()
	if txt.is_empty() or epic.is_empty():
		return ""
	if _is_active_feature_locked():
		_set_status("Baseline %s is read-only in this release." % _get_active_target_code(), false)
		return ""
	var feat: Dictionary = _get_active_feature()
	var target: Dictionary = feat if not feat.is_empty() else epic
	var fix_id: String = "fix_%d_%04d" % [int(Time.get_unix_time_from_system() * 1000.0), randi() % 10000]
	var open_v: Variant = target.get("openFixes", null)
	if typeof(open_v) != TYPE_ARRAY:
		open_v = []
		target["openFixes"] = open_v
	(open_v as Array).append({
		"id": fix_id,
		"text": txt,
		"resolved": false,
	})
	_sync_active_epic_summary_counts()
	_refresh_ui()
	_set_status("Logged [FIX] revision on %s." % _get_active_target_code(), false)
	if _sync_client != null and bool(_sync_client.call("has_link_token")):
		var mut := {
			"action": "log_fix",
			"epicId": str(epic.get("id", "")),
			"fixId": fix_id,
			"fixText": txt,
		}
		if not feat.is_empty():
			mut["featureId"] = str(feat.get("id", ""))
		_sync_client.call("push_epic_mutation", mut, _collect_live_context())
	return fix_id


func resolve_epic_fix_by_id(fix_id: String) -> void:
	var epic: Dictionary = _get_active_epic()
	if epic.is_empty():
		return
	if _is_active_feature_locked():
		_set_status("Baseline %s is read-only in this release." % _get_active_target_code(), false)
		return
	var feat: Dictionary = _get_active_feature()
	var target: Dictionary = feat if not feat.is_empty() else epic
	var open_v: Variant = target.get("openFixes", [])
	if typeof(open_v) == TYPE_ARRAY:
		var arr: Array = open_v as Array
		for i in range(arr.size() - 1, -1, -1):
			if typeof(arr[i]) == TYPE_DICTIONARY and str((arr[i] as Dictionary).get("id", "")) == fix_id:
				arr.remove_at(i)
	_sync_active_epic_summary_counts()
	_refresh_ui()
	_set_status("Marked [FIX] resolved.", false)
	if _sync_client != null and bool(_sync_client.call("has_link_token")):
		var mut := {
			"action": "resolve_fix",
			"epicId": str(epic.get("id", "")),
			"fixId": fix_id,
			"resolved": true,
		}
		if not feat.is_empty():
			mut["featureId"] = str(feat.get("id", ""))
		_sync_client.call("push_epic_mutation", mut, _collect_live_context())


func apply_epic_tuning_value(tkey: String, next_v: String, tunit: String = "") -> void:
	var clean_val: String = next_v.strip_edges()
	var epic: Dictionary = _get_active_epic()
	if clean_val.is_empty() or epic.is_empty():
		return
	if _is_active_feature_locked():
		_set_status("Baseline %s is read-only in this release." % _get_active_target_code(), false)
		return
	var feat: Dictionary = _get_active_feature()
	var target: Dictionary = feat if not feat.is_empty() else epic
	var tuning_v: Variant = target.get("tuning", [])
	if typeof(tuning_v) == TYPE_ARRAY:
		for tv in (tuning_v as Array):
			if typeof(tv) == TYPE_DICTIONARY and str((tv as Dictionary).get("key", "")) == tkey:
				(tv as Dictionary)["value"] = clean_val
				break
	var local_updated := false
	if _executor != null and _executor.has_method("apply_live_export_tuning"):
		var tune_res_v: Variant = _executor.call(
			"apply_live_export_tuning",
			_as_editor_interface(),
			tkey,
			clean_val,
			tunit,
			_resolve_play_scene_path()
		)
		if typeof(tune_res_v) == TYPE_DICTIONARY:
			local_updated = bool((tune_res_v as Dictionary).get("ok", false))
	if _sync_client != null and bool(_sync_client.call("has_link_token")):
		var mut := {
			"action": "update_tuning",
			"epicId": str(epic.get("id", "")),
			"key": tkey,
			"value": clean_val,
			"unit": tunit,
		}
		if not feat.is_empty():
			mut["featureId"] = str(feat.get("id", ""))
		_sync_client.call("push_epic_mutation", mut, _collect_live_context())
	if local_updated:
		_set_status("Updated %s = %s %s in local .gd/.tscn and Web Studio." % [tkey, clean_val, tunit], false)
	else:
		_set_status("Updated %s = %s %s in Web Studio." % [tkey, clean_val, tunit], false)


func _on_pass_reopen_pressed() -> void:
	var epic: Dictionary = _get_active_epic()
	if epic.is_empty() or _sync_client == null:
		return
	var feat: Dictionary = _get_active_feature()
	if _is_active_feature_locked():
		return
	if not feat.is_empty():
		var fact: String = "reopen_feature" if _get_active_target_is_passed() else "pass_feature"
		_sync_client.call("push_epic_mutation", {
			"action": fact,
			"epicId": str(epic.get("id", "")),
			"featureId": str(feat.get("id", "")),
		}, _collect_live_context())
		return
	var action: String = "reopen_epic" if bool(epic.get("isPassed", false)) else "pass_epic"
	_sync_client.call("push_epic_mutation", {
		"action": action,
		"epicId": str(epic.get("id", "")),
	}, _collect_live_context())


func _on_flag_fix_pressed() -> void:
	var txt: String = _fix_input.text.strip_edges()
	if txt.is_empty():
		return
	_fix_input.text = ""
	log_epic_fix_text(txt)


func _on_update_available(_local_ver: String, remote_ver: String) -> void:
	_manual_update_check = false
	_available_update_ver = remote_ver
	_update_label.text = "LAYERS v%s available" % remote_ver
	_update_banner.visible = true


func _on_update_check_finished(up_to_date: bool, local_ver: String, _remote_ver: String) -> void:
	var was_manual: bool = _manual_update_check
	_manual_update_check = false
	if was_manual and up_to_date:
		_set_status("LAYERS plugin v%s is up to date." % local_ver, false)


func _on_apply_update_pressed() -> void:
	if _sync_client == null:
		return
	_update_apply_btn.disabled = true
	_set_status("Updating LAYERS plugin...", false)
	_sync_client.call("download_and_apply_plugin_update")


func _on_update_ready_to_reload(new_ver: String, _updated_gd_paths: PackedStringArray) -> void:
	_update_banner.visible = false
	_update_apply_btn.disabled = false
	_set_status("Updated plugin to v%s. Disable & re-enable LAYERS in Project Settings → Plugins to reload." % new_ver, false)


func _on_update_failed(message: String) -> void:
	_manual_update_check = false
	_update_apply_btn.disabled = false
	_set_status(message, true)


func _set_status(msg: String, is_err: bool) -> void:
	_status_message = msg.strip_edges()
	_status_is_error = is_err
	if _status_label != null:
		_status_label.text = _status_message
		_status_label.visible = not _status_message.is_empty()
		if _status_is_error:
			_status_label.add_theme_color_override("font_color", Color(0.97, 0.44, 0.44))
		else:
			_status_label.add_theme_color_override("font_color", Color(0.45, 0.85, 0.72))


func _refresh_errors_card() -> void:
	if _errors_card == null or _errors_list_box == null:
		return
	for ch in _errors_list_box.get_children():
		ch.queue_free()
	var errs: Array[String] = _collect_recent_errors()
	_errors_card.visible = not errs.is_empty()
	for e in errs.slice(0, 5):
		var lbl := Label.new()
		lbl.text = "• %s" % e
		lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lbl.add_theme_font_size_override("font_size", 11)
		lbl.add_theme_color_override("font_color", Color(0.97, 0.65, 0.45))
		_errors_list_box.add_child(lbl)


func _refresh_ui() -> void:
	var linked: bool = _sync_client != null and bool(_sync_client.call("has_link_token"))
	var waiting_auth: bool = _sync_client != null and bool(_sync_client.call("is_waiting_for_auth"))

	_unlinked_panel.visible = not linked
	_cancel_signin_btn.visible = waiting_auth
	if _google_signin_btn != null:
		_google_signin_btn.text = "Waiting for Browser Sign-In..." if waiting_auth else "⚡ Sign in with Google"
		_google_signin_btn.disabled = waiting_auth
	_linked_scroll.visible = linked
	_sync_btn.visible = linked

	var dim_id: String = str(_payload.get("dimension", "dim3d")).strip_edges().to_lower()
	_dim_badge.text = "2D" if dim_id == "dim2d" else "3D"
	_undo_btn.disabled = _last_bundle_snapshot.is_empty()

	_refresh_errors_card()
	if not linked:
		return

	var proj_title: String = str(_payload.get("projectTitle", "LAYERS Project"))
	var rel_ver: String = str(_payload.get("releaseVersion", "v0.1"))
	var pos: int = int(_payload.get("epicPosition", 0))
	var total: int = int(_payload.get("totalEpics", 0))
	_project_meta_label.text = "%s · %s (%d/%d Epics)" % [proj_title, rel_ver, pos, total]

	var epic: Dictionary = _get_active_epic()
	var active_eid: String = str(epic.get("id", ""))
	var feat: Dictionary = _get_active_feature()
	var active_fid: String = str(feat.get("id", ""))
	var locked: bool = _is_active_feature_locked()

	# Populate Epic OptionButton
	_epic_selector.clear()
	var summary_v: Variant = _payload.get("releaseEpicsSummary", [])
	var selected_dropdown_idx: int = -1
	if typeof(summary_v) == TYPE_ARRAY:
		var summary_arr: Array = summary_v as Array
		for i in range(summary_arr.size()):
			if typeof(summary_arr[i]) != TYPE_DICTIONARY:
				continue
			var sdict: Dictionary = summary_arr[i] as Dictionary
			var sid: String = str(sdict.get("id", ""))
			var scode: String = str(sdict.get("code", "E01"))
			var stitle: String = str(sdict.get("title", "Epic"))
			var s_passed: bool = bool(sdict.get("isPassed", false))
			var s_fixes: int = int(sdict.get("openFixesCount", 0))
			var icon_tag: String = "✓" if s_passed else ("!" if s_fixes > 0 else "→")
			_epic_selector.add_item("%s %s · %s" % [icon_tag, scode, stitle])
			var item_idx: int = _epic_selector.item_count - 1
			_epic_selector.set_item_metadata(item_idx, sid)
			if sid == active_eid:
				selected_dropdown_idx = item_idx
	if selected_dropdown_idx >= 0:
		_epic_selector.select(selected_dropdown_idx)

	# Populate Feature OptionButton when 4-tier activeEpicFeatures exist
	if _feature_selector != null:
		_feature_selector.clear()
		var feats_v: Variant = _payload.get("activeEpicFeatures", [])
		var feats_arr: Array = feats_v as Array if typeof(feats_v) == TYPE_ARRAY else []
		_feature_selector.visible = not feats_arr.is_empty()
		var sel_f_idx: int = -1
		for i in range(feats_arr.size()):
			if typeof(feats_arr[i]) != TYPE_DICTIONARY:
				continue
			var fdict: Dictionary = feats_arr[i] as Dictionary
			var fid: String = str(fdict.get("id", ""))
			var fcode: String = str(fdict.get("code", "F01"))
			var ftitle: String = str(fdict.get("title", "Feature"))
			var f_locked: bool = bool(fdict.get("isLockedBaseline", false))
			var f_passed: bool = bool(fdict.get("isPassed", false))
			var f_fixes: int = int(fdict.get("openFixesCount", 0))
			var f_icon: String = "🔒" if f_locked else ("✓" if f_passed else ("!" if f_fixes > 0 else "→"))
			_feature_selector.add_item("%s %s · %s" % [f_icon, fcode, ftitle])
			var f_item_idx: int = _feature_selector.item_count - 1
			_feature_selector.set_item_metadata(f_item_idx, fid)
			if fid == active_fid:
				sel_f_idx = f_item_idx
		if sel_f_idx >= 0:
			_feature_selector.select(sel_f_idx)

	if _locked_baseline_label != null:
		_locked_baseline_label.visible = locked
		if locked:
			_locked_baseline_label.text = "%s shipped in %s baseline (read-only in %s)." % [
				_get_active_target_code(),
				str(feat.get("introducedIn", "v0.1")),
				rel_ver,
			]

	if epic.is_empty():
		_goal_label.text = "No active Epic yet. Approve Epics in LAYERS Web Studio and click ↻ Sync."
		_primary_cta_btn.text = "↻ Sync Specs"
		return

	var has_feat: bool = not feat.is_empty()
	if _goal_hdr != null:
		_goal_hdr.text = "§01 FEATURE SCOPE" if has_feat else "§01 EPIC INTENT"
	if _tuning_hdr != null:
		_tuning_hdr.text = "§03 @export TUNING" if has_feat else "§04 @export TUNING"
	if _checks_hdr != null:
		_checks_hdr.text = "§05 PLAYTEST GATE" if has_feat else "§06 PLAYTEST GATE"

	var target: Dictionary = _get_active_target()
	var tcode: String = _get_active_target_code()
	var checks: Array = _get_active_target_checks()
	var is_passed: bool = _get_active_target_is_passed()
	var cta: Dictionary = compute_primary_cta_state()
	_primary_cta_btn.text = str(cta.get("text", "⚡ Build %s" % tcode))
	var agent_busy_now: bool = (_sync_client != null and bool(_sync_client.call("is_agent_busy"))) or bool(_agent_session.get("active", false))
	if _cancel_agent_btn != null:
		_cancel_agent_btn.visible = agent_busy_now
		_cancel_agent_btn.disabled = not agent_busy_now
	_primary_cta_btn.disabled = agent_busy_now or locked
	_auto_fix_errors_btn.disabled = agent_busy_now or locked
	_pass_reopen_btn.disabled = agent_busy_now or locked
	_flag_fix_btn.disabled = agent_busy_now or locked
	_undo_btn.disabled = agent_busy_now or _last_bundle_snapshot.is_empty()
	if _fix_input != null:
		_fix_input.editable = not locked

	_goal_label.text = str(target.get("goal", ""))

	# Upgrade deltas
	for ch in _deltas_box.get_children():
		ch.queue_free()
	if has_feat:
		var rdelta: String = str(feat.get("releaseDelta", "")).strip_edges().trim_prefix("+").strip_edges()
		if not rdelta.is_empty():
			var d_lbl := Label.new()
			d_lbl.text = "• +%s" % rdelta
			d_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			d_lbl.add_theme_font_size_override("font_size", 11)
			d_lbl.add_theme_color_override("font_color", Color(0.49, 0.83, 0.99))
			_deltas_box.add_child(d_lbl)
	else:
		var deltas_v: Variant = epic.get("upgradeDeltas", [])
		if typeof(deltas_v) == TYPE_ARRAY:
			for dv in (deltas_v as Array):
				var d_lbl := Label.new()
				d_lbl.text = "• +%s" % str(dv).strip_edges().trim_prefix("+").strip_edges()
				d_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
				d_lbl.add_theme_font_size_override("font_size", 11)
				d_lbl.add_theme_color_override("font_color", Color(0.49, 0.83, 0.99))
				_deltas_box.add_child(d_lbl)

	# @export Tuning rows
	for ch in _tuning_box.get_children():
		ch.queue_free()
	var tuning_v: Variant = target.get("tuning", [])
	if typeof(tuning_v) == TYPE_ARRAY:
		for tv in (tuning_v as Array):
			if typeof(tv) != TYPE_DICTIONARY:
				continue
			var td: Dictionary = tv as Dictionary
			var tkey: String = str(td.get("key", ""))
			var tval: String = str(td.get("value", "0"))
			var tunit: String = str(td.get("unit", ""))

			var row := HBoxContainer.new()
			row.add_theme_constant_override("separation", 6)
			_tuning_box.add_child(row)

			var klbl := Label.new()
			klbl.text = tkey
			klbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			klbl.add_theme_font_size_override("font_size", 11)
			row.add_child(klbl)

			var v_edit := LineEdit.new()
			v_edit.text = tval
			v_edit.editable = not locked
			v_edit.custom_minimum_size = Vector2(68, 0)
			row.add_child(v_edit)

			if not tunit.is_empty():
				var ulbl := Label.new()
				ulbl.text = tunit
				ulbl.add_theme_font_size_override("font_size", 10)
				row.add_child(ulbl)

			var set_btn := Button.new()
			set_btn.text = "Set"
			set_btn.disabled = locked
			row.add_child(set_btn)

			var commit_tuning := func() -> void:
				apply_epic_tuning_value(tkey, v_edit.text, tunit)

			set_btn.pressed.connect(commit_tuning)
			v_edit.text_submitted.connect(func(_s: String) -> void: commit_tuning.call())

	# Playtest Gate checkboxes
	for ch in _checks_box.get_children():
		ch.queue_free()
	for cv in checks:
		if typeof(cv) != TYPE_DICTIONARY:
			continue
		var cd: Dictionary = cv as Dictionary
		var cid: String = str(cd.get("id", ""))
		var ctext: String = str(cd.get("text", ""))
		var cpassed: bool = bool(cd.get("passed", false))
		var cb := CheckBox.new()
		cb.text = ctext
		cb.button_pressed = cpassed
		cb.disabled = locked
		cb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		cb.toggled.connect(func(pressed: bool) -> void:
			toggle_epic_check_by_id(cid, pressed)
		)
		_checks_box.add_child(cb)

	if locked:
		_pass_reopen_btn.text = "🔒 Baseline Locked"
	else:
		_pass_reopen_btn.text = "↺ Reopen %s" % tcode if is_passed else "✓ Pass %s Gate" % tcode

	# Open [FIX] items
	for ch in _fixes_box.get_children():
		ch.queue_free()
	var open_fixes_v: Variant = target.get("openFixes", [])
	if typeof(open_fixes_v) == TYPE_ARRAY and not (open_fixes_v as Array).is_empty():
		for fv in (open_fixes_v as Array):
			if typeof(fv) != TYPE_DICTIONARY:
				continue
			var fd: Dictionary = fv as Dictionary
			var fid: String = str(fd.get("id", ""))
			var ftext: String = str(fd.get("text", ""))

			var frow := HBoxContainer.new()
			frow.add_theme_constant_override("separation", 6)
			_fixes_box.add_child(frow)

			var flbl := Label.new()
			flbl.text = "[FIX] %s" % ftext
			flbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			flbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			flbl.add_theme_font_size_override("font_size", 11)
			flbl.add_theme_color_override("font_color", Color(0.97, 0.55, 0.55))
			frow.add_child(flbl)

			var res_btn := Button.new()
			res_btn.text = "✓"
			res_btn.disabled = locked
			res_btn.tooltip_text = "Mark [FIX] resolved"
			res_btn.pressed.connect(func() -> void:
				resolve_epic_fix_by_id(fid)
			)
			frow.add_child(res_btn)
	else:
		var none_lbl := Label.new()
		none_lbl.text = "No open [FIX] revisions."
		none_lbl.add_theme_font_size_override("font_size", 11)
		_fixes_box.add_child(none_lbl)
